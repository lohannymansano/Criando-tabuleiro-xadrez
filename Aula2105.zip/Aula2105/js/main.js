// Configuracoes iniciais
const tamanhoQuadrado = 30;
const espessuraLinha = 2;
const corQuadradoPreto = "#8b0000";
const corQuadradoBranco = "white";

// Imagens das pecas
var imgBispo = new Image();
var imgCavalo = new Image();
var imgPeao = new Image();
var imgRainha = new Image();
var imgRei = new Image();
var imgTorre = new Image();

imgBispo.src = "./img/bispoXadrez.svg";
imgCavalo.src = "./img/cavaloXadrez.svg";
imgPeao.src = "./img/peaoXadrez.svg";
imgRainha.src = "./img/rainhaXadrez.svg";
imgRei.src = "./img/reiXadrez.svg";
imgTorre.src = "./img/torreXadrez.svg";

locaisTorre = [[1,1],[1,8],[8,1],[8,8]]
locaisCavalo = [[1,2],[1,7],[8,2],[8,7]]
locaisBispo = [[1,3],[1,6],[8,3],[8,6]]
locaisRainha = [[1,4],[8,4]]
locaisRei =  [[1,5],[8,5]]
locaisPeao = [[2,1],[2,2],[2,3],[2,4],[2,5],[2,6],[2,7],[2,8],[7,1],[7,2],[7,3],[7,4],[7,5],[7,6],[7,7],[7,8]]


// Referenciando o Canvas
var canvas = document.getElementById("meu_canvas");

// Obtendo o contexto gráfico
var context = canvas.getContext("2d");


for (i = 1; i <= 8; i++) {
  for (j = 1; j <= 8; j++) {
    // cor = ((i % 2) - (j % 2)) == 0 ? corQuadradoBranco : corQuadradoPreto;
    desenhaQuadrado(i, j, cor);
  }
}


//desenha as peças
 desenhaPeca(locaisTorre,imgTorre);
 desenhaPeca(locaisCavalo,imgCavalo);
 desenhaPeca(locaisBispo,imgBispo);
 desenhaPeca(locaisRainha,imgRainha);
 desenhaPeca(locaisRei,imgRei);
 desenhaPeca(locaisPeao,imgPeao);

// Desenhar Quadrado

function desenhaQuadrado(x, y, cor) {
  x = x * tamanhoQuadrado;
  y = y * tamanhoQuadrado;
  context.fillStyle = cor;
  context.fillRect(y, x, tamanhoQuadrado, tamanhoQuadrado);
  // Contorno azul, com espessura de 3px
  context.lineWidth = espessuraLinha;
  context.strokeStyle = "black";
  context.strokeRect(y, x, tamanhoQuadrado, tamanhoQuadrado);
}

function desenhaPeca(locaisPeca,imgPeca) {
  
  if (imgPeca != null) {
    imgPeca.onload = () => {

      locaisPeca.map((local) => {
        console.log(local[0],local[1])
        x = local[0] * tamanhoQuadrado;
        y = local[1] * tamanhoQuadrado;

        context.drawImage(
          imgPeca,
          y + 1,
          x + 1,
          tamanhoQuadrado - 3,
          tamanhoQuadrado - 3
        );
    
      })

    };
  }
}